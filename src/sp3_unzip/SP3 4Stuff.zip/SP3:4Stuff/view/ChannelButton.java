package view;

import javafx.scene.control.Button;

public class ChannelButton extends Button
{

}
