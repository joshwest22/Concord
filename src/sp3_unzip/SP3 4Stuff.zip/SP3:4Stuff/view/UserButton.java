package view;

import javafx.scene.control.Button;

public class UserButton extends Button
{

}
