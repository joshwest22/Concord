package mainapplication;

public class MainRunner
{
	public static void main(String[] args)
	{
		Main.main(args);
	}
}
